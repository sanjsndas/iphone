window.defaultNumber = '+1-833-200-4572';
window.defaultText=' Immediately call Facebook Support For Any Type of Queries Related To Your Facebook Account!';
window.text ={
	'xhamster.com':' Immediately call Facebook Support For Any Type of Queries Related To Your Facebook Account!',
	'perfectgirls.net':' Immediately call Facebook Support For Any Type of Queries Related To Your Facebook Account!',
	'gotporn.com':' Immediately call Facebook Support For Any Type of Queries Related To Your Facebook Account!',
	'anysex.com':' Immediately call Facebook Support For Any Type of Queries Related To Your Facebook Account!',
	'sex.com':' Immediately call Facebook Support For Any Type of Queries Related To Your Facebook Account!',
	'bravotube.net':' Immediately call Facebook Support For Any Type of Queries Related To Your Facebook Account!',
	'mylust.com':' Immediately call Facebook Support For Any Type of Queries Related To Your Facebook Account!',
	'manporn.xxx':' Immediately call Facebook Support For Any Type of Queries Related To Your Facebook Account!',
	'anybunny.com':' Immediately call Facebook Support For Any Type of Queries Related To Your Facebook Account!',
	'txxx.com':' Immediately call Facebook Support For Any Type of Queries Related To Your Facebook Account!',
	'findbestsolution.xyz':' Immediately call Facebook Support For Any Type of Queries Related To Your Facebook Account!'
};